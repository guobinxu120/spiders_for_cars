/**/_xdc_._746q0w && _xdc_._746q0w( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "33000",
               "short_name" : "33000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Bordeaux",
               "short_name" : "Bordeaux",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Gironde",
               "short_name" : "Gironde",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Nouvelle-Aquitaine",
               "short_name" : "Nouvelle-Aquitaine",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "33000 Bordeaux, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 44.8592596,
                  "lng" : -0.5640413
               },
               "southwest" : {
                  "lat" : 44.8183497,
                  "lng" : -0.6148519
               }
            },
            "location" : {
               "lat" : 44.8350088,
               "lng" : -0.5872689999999999
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 44.8592596,
                  "lng" : -0.5640413
               },
               "southwest" : {
                  "lat" : 44.8183497,
                  "lng" : -0.6148519
               }
            }
         },
         "place_id" : "ChIJUT6ddu8nVQ0RIIOvkRplBhw",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )