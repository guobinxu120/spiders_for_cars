/**/_xdc_._x3hq3a && _xdc_._x3hq3a( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "28000",
               "short_name" : "28000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Chartres",
               "short_name" : "Chartres",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Eure-et-Loir",
               "short_name" : "Eure-et-Loir",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Centre-Val de Loire",
               "short_name" : "Centre-Val de Loire",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "28000 Chartres, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 48.4690437,
                  "lng" : 1.5494115
               },
               "southwest" : {
                  "lat" : 48.42681,
                  "lng" : 1.4600832
               }
            },
            "location" : {
               "lat" : 48.4439486,
               "lng" : 1.5035523
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 48.4690437,
                  "lng" : 1.5494115
               },
               "southwest" : {
                  "lat" : 48.42681,
                  "lng" : 1.4600832
               }
            }
         },
         "place_id" : "ChIJnUTyE7YN5EcR4AlIRdrIDRw",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )