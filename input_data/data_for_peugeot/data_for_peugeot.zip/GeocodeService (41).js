/**/_xdc_._xmuip && _xdc_._xmuip( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "42000",
               "short_name" : "42000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Saint-Étienne",
               "short_name" : "Saint-Étienne",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Loire",
               "short_name" : "Loire",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Auvergne-Rhône-Alpes",
               "short_name" : "Auvergne-Rhône-Alpes",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "42000 Saint-Étienne, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 45.476735,
                  "lng" : 4.4260018
               },
               "southwest" : {
                  "lat" : 45.4270372,
                  "lng" : 4.3524723
               }
            },
            "location" : {
               "lat" : 45.450626,
               "lng" : 4.3859432
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 45.476735,
                  "lng" : 4.4260018
               },
               "southwest" : {
                  "lat" : 45.4270372,
                  "lng" : 4.3524723
               }
            }
         },
         "place_id" : "ChIJyfhNDA-s9UcRMFoOKbM8CRw",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )