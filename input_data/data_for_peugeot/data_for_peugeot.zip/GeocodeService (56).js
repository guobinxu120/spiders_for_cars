/**/_xdc_._6oxnd1 && _xdc_._6oxnd1( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "57000",
               "short_name" : "57000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Metz",
               "short_name" : "Metz",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Moselle",
               "short_name" : "Moselle",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Grand Est",
               "short_name" : "Grand Est",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "57000 Metz, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 49.1440385,
                  "lng" : 6.217542099999999
               },
               "southwest" : {
                  "lat" : 49.0608262,
                  "lng" : 6.1482299
               }
            },
            "location" : {
               "lat" : 49.1193074,
               "lng" : 6.1757236
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 49.1440385,
                  "lng" : 6.217542099999999
               },
               "southwest" : {
                  "lat" : 49.0608262,
                  "lng" : 6.1482299
               }
            }
         },
         "place_id" : "ChIJGS0yxxXclEcRkMVxAL1fChw",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )