/**/_xdc_._3rhkly && _xdc_._3rhkly( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "19000",
               "short_name" : "19000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Tulle",
               "short_name" : "Tulle",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Correze",
               "short_name" : "Correze",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Nouvelle-Aquitaine",
               "short_name" : "Nouvelle-Aquitaine",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "19000 Tulle, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 45.3219349,
                  "lng" : 1.8214138
               },
               "southwest" : {
                  "lat" : 45.2388682,
                  "lng" : 1.7229772
               }
            },
            "location" : {
               "lat" : 45.2764548,
               "lng" : 1.7618823
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 45.3219349,
                  "lng" : 1.8214138
               },
               "southwest" : {
                  "lat" : 45.2388682,
                  "lng" : 1.7229772
               }
            }
         },
         "place_id" : "ChIJ11I1A1aL-EcRQGOFqpXTBRw",
         "postcode_localities" : [ "Les Angles-sur-Corrèze", "Tulle" ],
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )