/**/_xdc_._8y1are && _xdc_._8y1are( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "49000",
               "short_name" : "49000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Angers",
               "short_name" : "Angers",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Maine-et-Loire",
               "short_name" : "Maine-et-Loire",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Pays de la Loire",
               "short_name" : "Pays de la Loire",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "49000 Angers, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 47.5584151,
                  "lng" : -0.4888921000000001
               },
               "southwest" : {
                  "lat" : 47.4373461,
                  "lng" : -0.6176845999999999
               }
            },
            "location" : {
               "lat" : 47.501835,
               "lng" : -0.517146
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 47.5584151,
                  "lng" : -0.4888921000000001
               },
               "southwest" : {
                  "lat" : 47.4373461,
                  "lng" : -0.6176845999999999
               }
            }
         },
         "place_id" : "ChIJtSqyXz15CEgRsB_goFU3DRw",
         "postcode_localities" : [ "Angers", "Écouflant" ],
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )