/**/_xdc_._zg6q5h && _xdc_._zg6q5h( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "81000",
               "short_name" : "81000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Albi",
               "short_name" : "Albi",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Tarn",
               "short_name" : "Tarn",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Occitanie",
               "short_name" : "Occitanie",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "81000 Albi, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 43.9695232,
                  "lng" : 2.2120001
               },
               "southwest" : {
                  "lat" : 43.8886868,
                  "lng" : 2.0530269
               }
            },
            "location" : {
               "lat" : 43.9329634,
               "lng" : 2.1548473
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 43.9695232,
                  "lng" : 2.2120001
               },
               "southwest" : {
                  "lat" : 43.8886868,
                  "lng" : 2.0530269
               }
            }
         },
         "place_id" : "ChIJC7eXebHCrRIRwLbZeJ_2Bhw",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )