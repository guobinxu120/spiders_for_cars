/**/_xdc_._leqefm && _xdc_._leqefm( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "92000",
               "short_name" : "92000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Nanterre",
               "short_name" : "Nanterre",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Hauts-de-Seine",
               "short_name" : "Hauts-de-Seine",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Île-de-France",
               "short_name" : "Île-de-France",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "92000 Nanterre, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 48.9205726,
                  "lng" : 2.2343695
               },
               "southwest" : {
                  "lat" : 48.8742071,
                  "lng" : 2.1687844
               }
            },
            "location" : {
               "lat" : 48.8941822,
               "lng" : 2.2071125
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 48.9205726,
                  "lng" : 2.2343695
               },
               "southwest" : {
                  "lat" : 48.8742071,
                  "lng" : 2.1687844
               }
            }
         },
         "place_id" : "ChIJu2Sd14dk5kcR0IDY4caCCxw",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )