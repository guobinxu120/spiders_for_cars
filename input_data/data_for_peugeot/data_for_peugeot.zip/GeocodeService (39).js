/**/_xdc_._8sjaqd && _xdc_._8sjaqd( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "Mont-de-Marsan",
               "short_name" : "Mont-de-Marsan",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Landes",
               "short_name" : "Landes",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Nouvelle-Aquitaine",
               "short_name" : "Nouvelle-Aquitaine",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            },
            {
               "long_name" : "40000",
               "short_name" : "40000",
               "types" : [ "postal_code" ]
            }
         ],
         "formatted_address" : "40000 Mont-de-Marsan, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 43.9315799,
                  "lng" : -0.446253
               },
               "southwest" : {
                  "lat" : 43.8546841,
                  "lng" : -0.5556011
               }
            },
            "location" : {
               "lat" : 43.893485,
               "lng" : -0.4997819999999999
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 43.9315799,
                  "lng" : -0.446253
               },
               "southwest" : {
                  "lat" : 43.8546841,
                  "lng" : -0.5556011
               }
            }
         },
         "place_id" : "ChIJ5xlGoxHRVQ0RoDMWSBdlBgQ",
         "types" : [ "locality", "political" ]
      }
   ],
   "status" : "OK"
}
 )