/**/_xdc_._dvho7z && _xdc_._dvho7z( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "09000",
               "short_name" : "09000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Celles",
               "short_name" : "Celles",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Ariege",
               "short_name" : "Ariege",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Occitanie",
               "short_name" : "Occitanie",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "09000 Celles, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 43.0426783,
                  "lng" : 1.7267914
               },
               "southwest" : {
                  "lat" : 42.860615,
                  "lng" : 1.4104277
               }
            },
            "location" : {
               "lat" : 42.9503046,
               "lng" : 1.5789994
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 43.0426783,
                  "lng" : 1.7267914
               },
               "southwest" : {
                  "lat" : 42.860615,
                  "lng" : 1.4104277
               }
            }
         },
         "place_id" : "ChIJmTlhvfIWrxIRMEnZeJ_2Bhw",
         "postcode_localities" : [
            "Arabaux",
            "Baulou",
            "Brassac",
            "Burret",
            "Bénac",
            "Celles",
            "Cos",
            "Ferrières-sur-Ariège",
            "Foix",
            "Ganac",
            "L'Herm",
            "Le Bosc",
            "Loubières",
            "Montgaillard",
            "Montoulieu",
            "Pradières",
            "Prayols",
            "Saint-Jean-de-Verges",
            "Saint-Martin-de-Caralp",
            "Saint-Paul-de-Jarrat",
            "Saint-Pierre-de-Rivière",
            "Serres-sur-Arget",
            "Soula",
            "Vernajoul"
         ],
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )