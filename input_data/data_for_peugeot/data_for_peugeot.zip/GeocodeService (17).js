/**/_xdc_._7oxsps && _xdc_._7oxsps( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "18000",
               "short_name" : "18000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Bourges",
               "short_name" : "Bourges",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Cher",
               "short_name" : "Cher",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Centre-Val de Loire",
               "short_name" : "Centre-Val de Loire",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "18000 Bourges, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 47.1302219,
                  "lng" : 2.4726043
               },
               "southwest" : {
                  "lat" : 47.0259779,
                  "lng" : 2.3237889
               }
            },
            "location" : {
               "lat" : 47.0818269,
               "lng" : 2.4039338
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 47.1302219,
                  "lng" : 2.4726043
               },
               "southwest" : {
                  "lat" : 47.0259779,
                  "lng" : 2.3237889
               }
            }
         },
         "place_id" : "ChIJPRQQX3mW-kcRUMYJiNrIDRw",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )