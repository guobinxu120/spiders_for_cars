/**/_xdc_._1xmzvg && _xdc_._1xmzvg( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "03000",
               "short_name" : "03000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Coulandon",
               "short_name" : "Coulandon",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Allier",
               "short_name" : "Allier",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Auvergne-Rhône-Alpes",
               "short_name" : "Auvergne-Rhône-Alpes",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "03000 Coulandon, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 46.6400392,
                  "lng" : 3.3592316
               },
               "southwest" : {
                  "lat" : 46.5042716,
                  "lng" : 3.1808387
               }
            },
            "location" : {
               "lat" : 46.5652137,
               "lng" : 3.2980018
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 46.6400392,
                  "lng" : 3.3592316
               },
               "southwest" : {
                  "lat" : 46.5042716,
                  "lng" : 3.1808387
               }
            }
         },
         "place_id" : "ChIJPcjiDHHi8EcRADUOKbM8CRw",
         "postcode_localities" : [ "Avermes", "Bressolles", "Coulandon", "Montilly", "Moulins", "Neuvy" ],
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )