/**/_xdc_._t61hzg && _xdc_._t61hzg( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "29000",
               "short_name" : "29000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Quimper",
               "short_name" : "Quimper",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Brittany",
               "short_name" : "Brittany",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "29000 Quimper, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 48.0659238,
                  "lng" : -4.0125613
               },
               "southwest" : {
                  "lat" : 47.930313,
                  "lng" : -4.1828413
               }
            },
            "location" : {
               "lat" : 47.9876054,
               "lng" : -4.097301799999999
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 48.0659238,
                  "lng" : -4.0125613
               },
               "southwest" : {
                  "lat" : 47.930313,
                  "lng" : -4.1828413
               }
            }
         },
         "place_id" : "ChIJLcRNo_LVEEgRcBP0dtClDBw",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )