/**/_xdc_._a1msrz && _xdc_._a1msrz( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "71000",
               "short_name" : "71000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Sancé",
               "short_name" : "Sancé",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Saône-et-Loire",
               "short_name" : "Saône-et-Loire",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Bourgogne-Franche-Comté",
               "short_name" : "Bourgogne-Franche-Comté",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "71000 Sancé, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 46.3797584,
                  "lng" : 4.8586377
               },
               "southwest" : {
                  "lat" : 46.25453630000001,
                  "lng" : 4.7575112
               }
            },
            "location" : {
               "lat" : 46.3280068,
               "lng" : 4.827469199999999
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 46.3797584,
                  "lng" : 4.8586377
               },
               "southwest" : {
                  "lat" : 46.25453630000001,
                  "lng" : 4.7575112
               }
            }
         },
         "place_id" : "ChIJwSB4yT1u80cR0P1HGTjOCRw",
         "postcode_localities" : [ "Mâcon", "Sancé", "Varennes-lès-Mâcon" ],
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )