/**/_xdc_._ycl84w && _xdc_._ycl84w( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "59000",
               "short_name" : "59000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Lille",
               "short_name" : "Lille",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Nord",
               "short_name" : "Nord",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Hauts-de-France",
               "short_name" : "Hauts-de-France",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "59000 Lille, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 50.6388279,
                  "lng" : 3.0913
               },
               "southwest" : {
                  "lat" : 50.6008053,
                  "lng" : 3.016796
               }
            },
            "location" : {
               "lat" : 50.6138111,
               "lng" : 3.0423599
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 50.6388279,
                  "lng" : 3.0913
               },
               "southwest" : {
                  "lat" : 50.6008053,
                  "lng" : 3.016796
               }
            }
         },
         "place_id" : "ChIJJdLeRp_VwkcRYAgl8UHxChw",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )