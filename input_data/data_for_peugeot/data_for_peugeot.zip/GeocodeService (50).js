/**/_xdc_._u9n001 && _xdc_._u9n001( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "51000",
               "short_name" : "51000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Châlons-en-Champagne",
               "short_name" : "Châlons-en-Champagne",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Marne",
               "short_name" : "Marne",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Grand Est",
               "short_name" : "Grand Est",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "51000 Châlons-en-Champagne, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 49.00098550000001,
                  "lng" : 4.430926599999999
               },
               "southwest" : {
                  "lat" : 48.9300933,
                  "lng" : 4.329041
               }
            },
            "location" : {
               "lat" : 48.9687925,
               "lng" : 4.3706849
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 49.00098550000001,
                  "lng" : 4.430926599999999
               },
               "southwest" : {
                  "lat" : 48.9300933,
                  "lng" : 4.329041
               }
            }
         },
         "place_id" : "ChIJxXjGWyLe60cRoKNxAL1fChw",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )