/**/_xdc_._hsxwbt && _xdc_._hsxwbt( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "08000",
               "short_name" : "08000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Charleville-Mézières",
               "short_name" : "Charleville-Mézières",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Ardennes",
               "short_name" : "Ardennes",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Grand Est",
               "short_name" : "Grand Est",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "08000 Charleville-Mézières, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 49.8275832,
                  "lng" : 4.7848486
               },
               "southwest" : {
                  "lat" : 49.71046090000001,
                  "lng" : 4.6333917
               }
            },
            "location" : {
               "lat" : 49.7488875,
               "lng" : 4.7112617
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 49.8275832,
                  "lng" : 4.7848486
               },
               "southwest" : {
                  "lat" : 49.71046090000001,
                  "lng" : 4.6333917
               }
            }
         },
         "place_id" : "ChIJY1atBRoO6kcRUIFxAL1fChw",
         "postcode_localities" : [
            "Charleville-Mézières",
            "Francheville",
            "Les Ayvelles",
            "Prix-lès-Mézières",
            "Villers-Semeuse",
            "Warcq"
         ],
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )