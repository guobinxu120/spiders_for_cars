/**/_xdc_._cvhiv8 && _xdc_._cvhiv8( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "48000",
               "short_name" : "48000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Barjac",
               "short_name" : "Barjac",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Lozère",
               "short_name" : "Lozère",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Occitanie",
               "short_name" : "Occitanie",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "48000 Barjac, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 44.6258399,
                  "lng" : 3.6654432
               },
               "southwest" : {
                  "lat" : 44.41408939999999,
                  "lng" : 3.3681604
               }
            },
            "location" : {
               "lat" : 44.5149147,
               "lng" : 3.5205641
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 44.6258399,
                  "lng" : 3.6654432
               },
               "southwest" : {
                  "lat" : 44.41408939999999,
                  "lng" : 3.3681604
               }
            }
         },
         "place_id" : "ChIJE1aiYGlusxIREOuMaSSIBxw",
         "postcode_localities" : [
            "Badaroux",
            "Balsièges",
            "Barjac",
            "Brenoux",
            "Chastel-Nouvel",
            "Lanuéjols",
            "Le Born",
            "Mende",
            "Pelouse",
            "Saint-Bauzile",
            "Saint-Étienne-du-Valdonnez",
            "Servières"
         ],
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )