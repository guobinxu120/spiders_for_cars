/**/_xdc_._meqjsd && _xdc_._meqjsd( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "53000",
               "short_name" : "53000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Laval",
               "short_name" : "Laval",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Mayenne",
               "short_name" : "Mayenne",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Pays de la Loire",
               "short_name" : "Pays de la Loire",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "53000 Laval, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 48.091876,
                  "lng" : -0.7175800000000001
               },
               "southwest" : {
                  "lat" : 48.0244266,
                  "lng" : -0.8207865
               }
            },
            "location" : {
               "lat" : 48.0678944,
               "lng" : -0.7646412
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 48.091876,
                  "lng" : -0.7175800000000001
               },
               "southwest" : {
                  "lat" : 48.0244266,
                  "lng" : -0.8207865
               }
            }
         },
         "place_id" : "ChIJwWtZ_On9CEgRADPgoFU3DRw",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )