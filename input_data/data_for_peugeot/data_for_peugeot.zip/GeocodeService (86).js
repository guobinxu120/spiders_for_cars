/**/_xdc_._bvhdih && _xdc_._bvhdih( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "87000",
               "short_name" : "87000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Limoges",
               "short_name" : "Limoges",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Haute-Vienne",
               "short_name" : "Haute-Vienne",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Nouvelle-Aquitaine",
               "short_name" : "Nouvelle-Aquitaine",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "87000 Limoges, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 45.85389480000001,
                  "lng" : 1.3067716
               },
               "southwest" : {
                  "lat" : 45.7888046,
                  "lng" : 1.1952334
               }
            },
            "location" : {
               "lat" : 45.8162774,
               "lng" : 1.2623048
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 45.85389480000001,
                  "lng" : 1.3067716
               },
               "southwest" : {
                  "lat" : 45.7888046,
                  "lng" : 1.1952334
               }
            }
         },
         "place_id" : "ChIJmazsdqo0-UcRoMeFqpXTBRw",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )