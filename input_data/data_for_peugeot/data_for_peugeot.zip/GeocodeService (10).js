/**/_xdc_._z73dgm && _xdc_._z73dgm( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "11000",
               "short_name" : "11000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Carcassonne",
               "short_name" : "Carcassonne",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Aude",
               "short_name" : "Aude",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Occitanie",
               "short_name" : "Occitanie",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "11000 Carcassonne, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 43.2442278,
                  "lng" : 2.4346162
               },
               "southwest" : {
                  "lat" : 43.1712778,
                  "lng" : 2.2622287
               }
            },
            "location" : {
               "lat" : 43.2183848,
               "lng" : 2.3517526
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 43.2442278,
                  "lng" : 2.4346162
               },
               "southwest" : {
                  "lat" : 43.1712778,
                  "lng" : 2.2622287
               }
            }
         },
         "place_id" : "ChIJHZTcxkksrhIR0LyMaSSIBxw",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )