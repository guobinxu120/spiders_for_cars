/**/_xdc_._t9muna && _xdc_._t9muna( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "90000",
               "short_name" : "90000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Belfort",
               "short_name" : "Belfort",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Territoire de Belfort",
               "short_name" : "Territoire de Belfort",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Bourgogne-Franche-Comté",
               "short_name" : "Bourgogne-Franche-Comté",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "90000 Belfort, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 47.6714262,
                  "lng" : 6.8947
               },
               "southwest" : {
                  "lat" : 47.6205165,
                  "lng" : 6.7874095
               }
            },
            "location" : {
               "lat" : 47.6437604,
               "lng" : 6.8437053
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 47.6714262,
                  "lng" : 6.8947
               },
               "southwest" : {
                  "lat" : 47.6205165,
                  "lng" : 6.7874095
               }
            }
         },
         "place_id" : "ChIJ4UhO_Hg7kkcR8BJIGTjOCRw",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )