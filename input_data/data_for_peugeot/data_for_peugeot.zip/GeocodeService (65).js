/**/_xdc_._idruu && _xdc_._idruu( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "66000",
               "short_name" : "66000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Perpignan",
               "short_name" : "Perpignan",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Pyrénées-Orientales",
               "short_name" : "Pyrénées-Orientales",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Occitanie",
               "short_name" : "Occitanie",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "66000 Perpignan, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 42.7491599,
                  "lng" : 2.9827493
               },
               "southwest" : {
                  "lat" : 42.6529815,
                  "lng" : 2.8266403
               }
            },
            "location" : {
               "lat" : 42.7201813,
               "lng" : 2.8876436
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 42.7491599,
                  "lng" : 2.9827493
               },
               "southwest" : {
                  "lat" : 42.6529815,
                  "lng" : 2.8266403
               }
            }
         },
         "place_id" : "ChIJw2A8Ma5vsBIR4O2MaSSIBxw",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )