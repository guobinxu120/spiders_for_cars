/**/_xdc_._amdvgv && _xdc_._amdvgv( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "56000",
               "short_name" : "56000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Vannes",
               "short_name" : "Vannes",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Morbihan",
               "short_name" : "Morbihan",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Brittany",
               "short_name" : "Brittany",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "56000 Vannes, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 47.69451859999999,
                  "lng" : -2.6814094
               },
               "southwest" : {
                  "lat" : 47.62070689999999,
                  "lng" : -2.8149415
               }
            },
            "location" : {
               "lat" : 47.6617064,
               "lng" : -2.7574616
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 47.69451859999999,
                  "lng" : -2.6814094
               },
               "southwest" : {
                  "lat" : 47.62070689999999,
                  "lng" : -2.8149415
               }
            }
         },
         "place_id" : "ChIJ774HMIceEEgRcGL0dtClDBw",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )