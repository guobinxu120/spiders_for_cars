/**/_xdc_._yruasr && _xdc_._yruasr( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "35000",
               "short_name" : "35000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Rennes",
               "short_name" : "Rennes",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Ille-et-Vilaine",
               "short_name" : "Ille-et-Vilaine",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Brittany",
               "short_name" : "Brittany",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "35000 Rennes, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 48.14416199999999,
                  "lng" : -1.6245075
               },
               "southwest" : {
                  "lat" : 48.07989120000001,
                  "lng" : -1.752466
               }
            },
            "location" : {
               "lat" : 48.11734209999999,
               "lng" : -1.7075198
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 48.14416199999999,
                  "lng" : -1.6245075
               },
               "southwest" : {
                  "lat" : 48.07989120000001,
                  "lng" : -1.752466
               }
            }
         },
         "place_id" : "ChIJ9VR4MizeDkgRkBz0dtClDBw",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )