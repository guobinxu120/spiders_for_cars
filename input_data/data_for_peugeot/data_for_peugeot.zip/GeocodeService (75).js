/**/_xdc_._pwxp8c && _xdc_._pwxp8c( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "76000",
               "short_name" : "76000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Rouen",
               "short_name" : "Rouen",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Seine-Maritime",
               "short_name" : "Seine-Maritime",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Normandy",
               "short_name" : "Normandy",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "76000 Rouen, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 49.4652107,
                  "lng" : 1.1522007
               },
               "southwest" : {
                  "lat" : 49.4278302,
                  "lng" : 1.0375465
               }
            },
            "location" : {
               "lat" : 49.4464909,
               "lng" : 1.0976001
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 49.4652107,
                  "lng" : 1.1522007
               },
               "southwest" : {
                  "lat" : 49.4278302,
                  "lng" : 1.0375465
               }
            }
         },
         "place_id" : "ChIJgVuzKtHd4EcRsHvKj0sUDBw",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )