/**/_xdc_._3lzkkx && _xdc_._3lzkkx( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "10000",
               "short_name" : "10000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Troyes",
               "short_name" : "Troyes",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Aube",
               "short_name" : "Aube",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Grand Est",
               "short_name" : "Grand Est",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "10000 Troyes, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 48.318476,
                  "lng" : 4.111469
               },
               "southwest" : {
                  "lat" : 48.2662536,
                  "lng" : 4.041142199999999
               }
            },
            "location" : {
               "lat" : 48.3016758,
               "lng" : 4.0798157
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 48.318476,
                  "lng" : 4.111469
               },
               "southwest" : {
                  "lat" : 48.2662536,
                  "lng" : 4.041142199999999
               }
            }
         },
         "place_id" : "ChIJn_LdL_mY7kcRoIZxAL1fChw",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )