/**/_xdc_._7y15en && _xdc_._7y15en( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "88000",
               "short_name" : "88000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Chantraine",
               "short_name" : "Chantraine",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Vosges",
               "short_name" : "Vosges",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Grand Est",
               "short_name" : "Grand Est",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "88000 Chantraine, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 48.2552504,
                  "lng" : 6.579648799999999
               },
               "southwest" : {
                  "lat" : 48.1195876,
                  "lng" : 6.393624699999999
               }
            },
            "location" : {
               "lat" : 48.1945182,
               "lng" : 6.5142872
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 48.2552504,
                  "lng" : 6.579648799999999
               },
               "southwest" : {
                  "lat" : 48.1195876,
                  "lng" : 6.393624699999999
               }
            }
         },
         "place_id" : "ChIJHXEgE02gk0cRYAZyAL1fChw",
         "postcode_localities" : [
            "Chantraine",
            "Deyvillers",
            "Dignonville",
            "Dinozé",
            "Dogneville",
            "Jeuxey",
            "Longchamp",
            "Vaudéville",
            "Épinal"
         ],
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )