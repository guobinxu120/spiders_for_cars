/**/_xdc_._rc6x8y && _xdc_._rc6x8y( {
   "results" : [],
   "status" : "ZERO_RESULTS"
}
 )