/**/_xdc_._40kxat && _xdc_._40kxat( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "89000",
               "short_name" : "89000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Perrigny",
               "short_name" : "Perrigny",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Yonne",
               "short_name" : "Yonne",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Bourgogne-Franche-Comté",
               "short_name" : "Bourgogne-Franche-Comté",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "89000 Perrigny, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 47.8523217,
                  "lng" : 3.6373709
               },
               "southwest" : {
                  "lat" : 47.7530456,
                  "lng" : 3.4799029
               }
            },
            "location" : {
               "lat" : 47.7973595,
               "lng" : 3.5659504
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 47.8523217,
                  "lng" : 3.6373709
               },
               "southwest" : {
                  "lat" : 47.7530456,
                  "lng" : 3.4799029
               }
            }
         },
         "place_id" : "ChIJya5yQClP7kcR4AtIGTjOCRw",
         "postcode_localities" : [ "Auxerre", "Perrigny", "Saint-Georges-sur-Baulche" ],
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )