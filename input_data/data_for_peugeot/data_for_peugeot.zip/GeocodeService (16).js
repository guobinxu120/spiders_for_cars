/**/_xdc_._bme0tm && _xdc_._bme0tm( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "17000",
               "short_name" : "17000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Nouvelle-Aquitaine",
               "short_name" : "Nouvelle-Aquitaine",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "17000, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 46.19100040000001,
                  "lng" : -1.1113177
               },
               "southwest" : {
                  "lat" : 46.1331208,
                  "lng" : -1.2417438
               }
            },
            "location" : {
               "lat" : 46.1600767,
               "lng" : -1.1774721
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 46.19100040000001,
                  "lng" : -1.1113177
               },
               "southwest" : {
                  "lat" : 46.1331208,
                  "lng" : -1.2417438
               }
            }
         },
         "place_id" : "ChIJdT0lyYNTAUgRsFiFqpXTBRw",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )