/**/_xdc_._e4l0wu && _xdc_._e4l0wu( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "79000",
               "short_name" : "79000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Sciecq",
               "short_name" : "Sciecq",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Deux-Sèvres",
               "short_name" : "Deux-Sèvres",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Nouvelle-Aquitaine",
               "short_name" : "Nouvelle-Aquitaine",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "79000 Sciecq, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 46.3776517,
                  "lng" : -0.3799435
               },
               "southwest" : {
                  "lat" : 46.2754385,
                  "lng" : -0.5491752999999999
               }
            },
            "location" : {
               "lat" : 46.3326748,
               "lng" : -0.4815849
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 46.3776517,
                  "lng" : -0.3799435
               },
               "southwest" : {
                  "lat" : 46.2754385,
                  "lng" : -0.5491752999999999
               }
            }
         },
         "place_id" : "ChIJt3VsSSwwB0gR8LOFqpXTBRw",
         "postcode_localities" : [ "Bessines", "Niort", "Sciecq" ],
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )