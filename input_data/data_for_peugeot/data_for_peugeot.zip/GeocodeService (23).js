/**/_xdc_._daqlj3 && _xdc_._daqlj3( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "24000",
               "short_name" : "24000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Périgueux",
               "short_name" : "Périgueux",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Dordogne",
               "short_name" : "Dordogne",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Nouvelle-Aquitaine",
               "short_name" : "Nouvelle-Aquitaine",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "24000 Périgueux, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 45.2140954,
                  "lng" : 0.7469530999999999
               },
               "southwest" : {
                  "lat" : 45.1743951,
                  "lng" : 0.6749936
               }
            },
            "location" : {
               "lat" : 45.1893384,
               "lng" : 0.7152934999999999
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 45.2140954,
                  "lng" : 0.7469530999999999
               },
               "southwest" : {
                  "lat" : 45.1743951,
                  "lng" : 0.6749936
               }
            }
         },
         "place_id" : "ChIJjQ06-Q9x_0cR0GmvkRplBhw",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )