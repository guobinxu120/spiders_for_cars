/**/_xdc_._caqg6c && _xdc_._caqg6c( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "63000",
               "short_name" : "63000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Clermont-Ferrand",
               "short_name" : "Clermont-Ferrand",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Puy-de-Dome",
               "short_name" : "Puy-de-Dome",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Auvergne-Rhône-Alpes",
               "short_name" : "Auvergne-Rhône-Alpes",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "63000 Clermont-Ferrand, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 45.7872433,
                  "lng" : 3.1722052
               },
               "southwest" : {
                  "lat" : 45.7556417,
                  "lng" : 3.0702933
               }
            },
            "location" : {
               "lat" : 45.771264,
               "lng" : 3.1198023
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 45.7872433,
                  "lng" : 3.1722052
               },
               "southwest" : {
                  "lat" : 45.7556417,
                  "lng" : 3.0702933
               }
            }
         },
         "place_id" : "ChIJ778YnxYc90cREGcOKbM8CRw",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )