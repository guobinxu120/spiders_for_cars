/**/_xdc_._y7383v && _xdc_._y7383v( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "50000",
               "short_name" : "50000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Rampan",
               "short_name" : "Rampan",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Manche",
               "short_name" : "Manche",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Normandy",
               "short_name" : "Normandy",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "50000 Rampan, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 49.1639748,
                  "lng" : -1.0360892
               },
               "southwest" : {
                  "lat" : 49.0748213,
                  "lng" : -1.1522403
               }
            },
            "location" : {
               "lat" : 49.1272183,
               "lng" : -1.0797778
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 49.1639748,
                  "lng" : -1.0360892
               },
               "southwest" : {
                  "lat" : 49.0748213,
                  "lng" : -1.1522403
               }
            }
         },
         "place_id" : "ChIJI6MOp4GWC0gRAFfKj0sUDBw",
         "postcode_localities" : [
            "Baudre",
            "Le Mesnil-Rouxelin",
            "Rampan",
            "Saint-Georges-Montcocq",
            "Saint-Lô"
         ],
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )