/**/_xdc_._gsxqz2 && _xdc_._gsxqz2( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "47000",
               "short_name" : "47000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Lot-et-Garonne",
               "short_name" : "Lot-et-Garonne",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Nouvelle-Aquitaine",
               "short_name" : "Nouvelle-Aquitaine",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "47000, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 44.22350429999999,
                  "lng" : 0.6527948
               },
               "southwest" : {
                  "lat" : 44.1786079,
                  "lng" : 0.6023052999999999
               }
            },
            "location" : {
               "lat" : 44.2035321,
               "lng" : 0.6251540999999999
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 44.22350429999999,
                  "lng" : 0.6527948
               },
               "southwest" : {
                  "lat" : 44.1786079,
                  "lng" : 0.6023052999999999
               }
            }
         },
         "place_id" : "ChIJD4OF_xqzqxIRIJqvkRplBhw",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )