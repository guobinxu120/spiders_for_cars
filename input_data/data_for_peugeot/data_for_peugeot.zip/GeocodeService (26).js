/**/_xdc_._1idx7l && _xdc_._1idx7l( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "27000",
               "short_name" : "27000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Évreux",
               "short_name" : "Évreux",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Eure",
               "short_name" : "Eure",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Normandy",
               "short_name" : "Normandy",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "27000 Évreux, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 49.0467374,
                  "lng" : 1.1894852
               },
               "southwest" : {
                  "lat" : 48.9893495,
                  "lng" : 1.0868791
               }
            },
            "location" : {
               "lat" : 49.0255821,
               "lng" : 1.1419556
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 49.0467374,
                  "lng" : 1.1894852
               },
               "southwest" : {
                  "lat" : 48.9893495,
                  "lng" : 1.0868791
               }
            }
         },
         "place_id" : "ChIJFzQAJxoN4UcRIAchlUsUDBw",
         "postcode_localities" : [
            "Caorches-Saint-Nicolas",
            "Malouy",
            "Plainville",
            "Saint-Martin-du-Tilleul",
            "Saint-Victor-de-Chrétienville",
            "Évreux"
         ],
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )