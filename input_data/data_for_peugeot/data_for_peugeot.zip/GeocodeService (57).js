/**/_xdc_._2rhf97 && _xdc_._2rhf97( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "58000",
               "short_name" : "58000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Challuy",
               "short_name" : "Challuy",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Nièvre",
               "short_name" : "Nièvre",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Bourgogne-Franche-Comté",
               "short_name" : "Bourgogne-Franche-Comté",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "58000 Challuy, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 47.0141583,
                  "lng" : 3.2641405
               },
               "southwest" : {
                  "lat" : 46.9088596,
                  "lng" : 3.1100425
               }
            },
            "location" : {
               "lat" : 46.95615040000001,
               "lng" : 3.1711675
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 47.0141583,
                  "lng" : 3.2641405
               },
               "southwest" : {
                  "lat" : 46.9088596,
                  "lng" : 3.1100425
               }
            }
         },
         "place_id" : "ChIJWyt7Q7FP8EcRINZHGTjOCRw",
         "postcode_localities" : [ "Challuy", "Nevers", "Saint-Éloi", "Sermoise-sur-Loire" ],
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )