/**/_xdc_._kqdz2w && _xdc_._kqdz2w( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "46000",
               "short_name" : "46000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Cahors",
               "short_name" : "Cahors",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Lot",
               "short_name" : "Lot",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Occitanie",
               "short_name" : "Occitanie",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "46000 Cahors, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 44.5119097,
                  "lng" : 1.5054511
               },
               "southwest" : {
                  "lat" : 44.4012914,
                  "lng" : 1.3721346
               }
            },
            "location" : {
               "lat" : 44.446599,
               "lng" : 1.4628042
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 44.5119097,
                  "lng" : 1.5054511
               },
               "southwest" : {
                  "lat" : 44.4012914,
                  "lng" : 1.3721346
               }
            }
         },
         "place_id" : "ChIJ-xR9VFeJrBIRUJbZeJ_2Bhw",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )