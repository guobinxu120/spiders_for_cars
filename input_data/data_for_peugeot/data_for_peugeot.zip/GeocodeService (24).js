/**/_xdc_._9dadf9 && _xdc_._9dadf9( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "25000",
               "short_name" : "25000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Besançon",
               "short_name" : "Besançon",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Doubs",
               "short_name" : "Doubs",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Bourgogne-Franche-Comté",
               "short_name" : "Bourgogne-Franche-Comté",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "25000 Besançon, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 47.3201118,
                  "lng" : 6.0836581
               },
               "southwest" : {
                  "lat" : 47.2007243,
                  "lng" : 5.9404594
               }
            },
            "location" : {
               "lat" : 47.2711117,
               "lng" : 6.0282445
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 47.3201118,
                  "lng" : 6.0836581
               },
               "southwest" : {
                  "lat" : 47.2007243,
                  "lng" : 5.9404594
               }
            }
         },
         "place_id" : "ChIJCxPu8PpijUcRMJRHGTjOCRw",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )