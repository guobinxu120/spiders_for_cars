/**/_xdc_._5v37za && _xdc_._5v37za( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "02000",
               "short_name" : "02000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Barenton-Cel",
               "short_name" : "Barenton-Cel",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Aisne",
               "short_name" : "Aisne",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Hauts-de-France",
               "short_name" : "Hauts-de-France",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "02000 Barenton-Cel, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 49.6717215,
                  "lng" : 3.707536
               },
               "southwest" : {
                  "lat" : 49.4228069,
                  "lng" : 3.4809264
               }
            },
            "location" : {
               "lat" : 49.5433545,
               "lng" : 3.6030655
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 49.6717215,
                  "lng" : 3.707536
               },
               "southwest" : {
                  "lat" : 49.4228069,
                  "lng" : 3.4809264
               }
            }
         },
         "place_id" : "ChIJF3UZGYdM6EcREPAk8UHxChw",
         "postcode_localities" : [
            "Aulnois-sous-Laon",
            "Barenton-Bugny",
            "Barenton-Cel",
            "Bourguignon-sous-Montbavin",
            "Braye-en-Laonnois",
            "Chaillevois",
            "Chambry",
            "Chavignon",
            "Chevregny",
            "Chivy-lès-Étouvelles",
            "Chéry-lès-Pouilly",
            "Clacy-et-Thierret",
            "Filain",
            "Laniscourt",
            "Laon",
            "Merlieux-et-Fouquerolles",
            "Molinchart",
            "Monampteuil",
            "Mons-en-Laonnois",
            "Montbavin",
            "Pargny-Filain",
            "Royaucourt-et-Chailvet",
            "Urcel",
            "Vaucelles-et-Beffecourt",
            "Verneuil-sur-Serre",
            "Étouvelles"
         ],
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )