/**/_xdc_._p339ul && _xdc_._p339ul( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "21000",
               "short_name" : "21000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Dijon",
               "short_name" : "Dijon",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Côte-d'Or",
               "short_name" : "Côte-d'Or",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Bourgogne-Franche-Comté",
               "short_name" : "Bourgogne-Franche-Comté",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "21000 Dijon, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 47.3779013,
                  "lng" : 5.102103899999999
               },
               "southwest" : {
                  "lat" : 47.2862365,
                  "lng" : 4.962494299999999
               }
            },
            "location" : {
               "lat" : 47.3237985,
               "lng" : 5.0386146
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 47.3779013,
                  "lng" : 5.102103899999999
               },
               "southwest" : {
                  "lat" : 47.2862365,
                  "lng" : 4.962494299999999
               }
            }
         },
         "place_id" : "ChIJdZb974yd8kcRsItHGTjOCRw",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )