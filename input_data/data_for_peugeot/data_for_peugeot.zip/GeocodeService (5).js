/**/_xdc_._pnucjh && _xdc_._pnucjh( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "06000",
               "short_name" : "06000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Nice",
               "short_name" : "Nice",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Alpes-Maritimes",
               "short_name" : "Alpes-Maritimes",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Provence-Alpes-Côte d'Azur",
               "short_name" : "Provence-Alpes-Côte d'Azur",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "06000 Nice, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 43.7462919,
                  "lng" : 7.2885164
               },
               "southwest" : {
                  "lat" : 43.6901713,
                  "lng" : 7.220439399999999
               }
            },
            "location" : {
               "lat" : 43.6960355,
               "lng" : 7.265589599999998
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 43.7462919,
                  "lng" : 7.2885164
               },
               "southwest" : {
                  "lat" : 43.6901713,
                  "lng" : 7.220439399999999
               }
            }
         },
         "place_id" : "ChIJFy_UVOPPzRIRMLm2UKkZCBw",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )