/**/_xdc_._o8l4iv && _xdc_._o8l4iv( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "69000",
               "short_name" : "69000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Lyon",
               "short_name" : "Lyon",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Rhône",
               "short_name" : "Rhône",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Auvergne-Rhône-Alpes",
               "short_name" : "Auvergne-Rhône-Alpes",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "69000 Lyon, France",
         "geometry" : {
            "location" : {
               "lat" : 45.7633815,
               "lng" : 4.834237700000001
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 45.771165,
                  "lng" : 4.8502451
               },
               "southwest" : {
                  "lat" : 45.7555969,
                  "lng" : 4.8182303
               }
            }
         },
         "place_id" : "ChIJi1_C-lXq9EcRwEnCdeZRopg",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )