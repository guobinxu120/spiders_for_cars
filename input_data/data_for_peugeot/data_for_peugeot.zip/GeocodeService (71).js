/**/_xdc_._646ko5 && _xdc_._646ko5( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "72000",
               "short_name" : "72000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Le Mans",
               "short_name" : "Le Mans",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Sarthe",
               "short_name" : "Sarthe",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Pays de la Loire",
               "short_name" : "Pays de la Loire",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "72000 Le Mans, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 48.0308169,
                  "lng" : 0.1894493
               },
               "southwest" : {
                  "lat" : 47.95444819999999,
                  "lng" : 0.1359246
               }
            },
            "location" : {
               "lat" : 48.0157803,
               "lng" : 0.1609266
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 48.0308169,
                  "lng" : 0.1894493
               },
               "southwest" : {
                  "lat" : 47.95444819999999,
                  "lng" : 0.1359246
               }
            }
         },
         "place_id" : "ChIJKRqT7vqF4kcRcEjgoFU3DRw",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )