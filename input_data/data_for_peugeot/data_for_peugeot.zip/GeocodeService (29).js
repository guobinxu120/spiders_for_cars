/**/_xdc_._iwjece && _xdc_._iwjece( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "30000",
               "short_name" : "30000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Nîmes",
               "short_name" : "Nîmes",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Gard",
               "short_name" : "Gard",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Occitanie",
               "short_name" : "Occitanie",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "30000 Nîmes, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 43.9248772,
                  "lng" : 4.449688699999999
               },
               "southwest" : {
                  "lat" : 43.8002425,
                  "lng" : 4.2709412
               }
            },
            "location" : {
               "lat" : 43.8791313,
               "lng" : 4.3770704
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 43.9248772,
                  "lng" : 4.449688699999999
               },
               "southwest" : {
                  "lat" : 43.8002425,
                  "lng" : 4.2709412
               }
            }
         },
         "place_id" : "ChIJ7SeiooEytBIRwNiMaSSIBxw",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )