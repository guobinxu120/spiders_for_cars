/**/_xdc_._fju8xg && _xdc_._fju8xg( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "16000",
               "short_name" : "16000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Angoulême",
               "short_name" : "Angoulême",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Charente",
               "short_name" : "Charente",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Nouvelle-Aquitaine",
               "short_name" : "Nouvelle-Aquitaine",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "16000 Angoulême, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 45.67153709999999,
                  "lng" : 0.1646157
               },
               "southwest" : {
                  "lat" : 45.6198069,
                  "lng" : 0.09976
               }
            },
            "location" : {
               "lat" : 45.647878,
               "lng" : 0.1433442
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 45.67153709999999,
                  "lng" : 0.1646157
               },
               "southwest" : {
                  "lat" : 45.6198069,
                  "lng" : 0.09976
               }
            }
         },
         "place_id" : "ChIJmcQrA4Ut_kcRcFCFqpXTBRw",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )