/**/_xdc_._g86oa6 && _xdc_._g86oa6( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "62000",
               "short_name" : "62000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Dainville",
               "short_name" : "Dainville",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Pas-de-Calais",
               "short_name" : "Pas-de-Calais",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Hauts-de-France",
               "short_name" : "Hauts-de-France",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "62000 Dainville, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 50.3104775,
                  "lng" : 2.810788
               },
               "southwest" : {
                  "lat" : 50.2591166,
                  "lng" : 2.6815565
               }
            },
            "location" : {
               "lat" : 50.29005189999999,
               "lng" : 2.7451657
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 50.3104775,
                  "lng" : 2.810788
               },
               "southwest" : {
                  "lat" : 50.2591166,
                  "lng" : 2.6815565
               }
            }
         },
         "place_id" : "ChIJDfkMYLdH3UcRMC4l8UHxChw",
         "postcode_localities" : [ "Arras", "Dainville" ],
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )