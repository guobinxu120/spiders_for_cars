/**/_xdc_._qc6rw7 && _xdc_._qc6rw7( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "52000",
               "short_name" : "52000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Neuilly-sur-Suize",
               "short_name" : "Neuilly-sur-Suize",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Haute-Marne",
               "short_name" : "Haute-Marne",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Grand Est",
               "short_name" : "Grand Est",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "52000 Neuilly-sur-Suize, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 48.19165659999999,
                  "lng" : 5.272309
               },
               "southwest" : {
                  "lat" : 48.0198774,
                  "lng" : 5.0008002
               }
            },
            "location" : {
               "lat" : 48.0845463,
               "lng" : 5.1461308
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 48.19165659999999,
                  "lng" : 5.272309
               },
               "southwest" : {
                  "lat" : 48.0198774,
                  "lng" : 5.0008002
               }
            }
         },
         "place_id" : "ChIJXR5aOW3l7EcRAK5xAL1fChw",
         "postcode_localities" : [
            "Brethenay",
            "Buxières-lès-Villiers",
            "Chamarandes-Choignes",
            "Chaumont",
            "Condes",
            "Euffigneix",
            "Jonchery",
            "Laville-aux-Bois",
            "Luzy-sur-Marne",
            "Neuilly-sur-Suize",
            "Riaucourt",
            "Semoutiers-Montsaon",
            "Treix",
            "Verbiesles",
            "Villiers-le-Sec"
         ],
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )