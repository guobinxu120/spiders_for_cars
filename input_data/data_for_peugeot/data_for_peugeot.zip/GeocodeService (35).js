/**/_xdc_._uue2ox && _xdc_._uue2ox( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "36000",
               "short_name" : "36000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Châteauroux",
               "short_name" : "Châteauroux",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Indre",
               "short_name" : "Indre",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Centre-Val de Loire",
               "short_name" : "Centre-Val de Loire",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "36000 Châteauroux, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 46.8298083,
                  "lng" : 1.7424276
               },
               "southwest" : {
                  "lat" : 46.7748461,
                  "lng" : 1.6382288
               }
            },
            "location" : {
               "lat" : 46.8031198,
               "lng" : 1.6926546
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 46.8298083,
                  "lng" : 1.7424276
               },
               "southwest" : {
                  "lat" : 46.7748461,
                  "lng" : 1.6382288
               }
            }
         },
         "place_id" : "ChIJMcZg2bqg-0cRUPwJiNrIDRw",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )