/**/_xdc_._neqp54 && _xdc_._neqp54( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "14000",
               "short_name" : "14000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Caen",
               "short_name" : "Caen",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Calvados",
               "short_name" : "Calvados",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Normandy",
               "short_name" : "Normandy",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "14000 Caen, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 49.21617810000001,
                  "lng" : -0.3304896
               },
               "southwest" : {
                  "lat" : 49.1530906,
                  "lng" : -0.4134274
               }
            },
            "location" : {
               "lat" : 49.1923387,
               "lng" : -0.3796444
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 49.21617810000001,
                  "lng" : -0.3304896
               },
               "southwest" : {
                  "lat" : 49.1530906,
                  "lng" : -0.4134274
               }
            }
         },
         "place_id" : "ChIJeytcqMFCCkgRMOPJj0sUDBw",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )