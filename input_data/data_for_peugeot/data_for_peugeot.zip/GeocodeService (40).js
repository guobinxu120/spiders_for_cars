/**/_xdc_._4v32mj && _xdc_._4v32mj( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "41000",
               "short_name" : "41000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Blois",
               "short_name" : "Blois",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Loir-et-Cher",
               "short_name" : "Loir-et-Cher",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Centre-Val de Loire",
               "short_name" : "Centre-Val de Loire",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "41000 Blois, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 47.6910195,
                  "lng" : 1.4106235
               },
               "southwest" : {
                  "lat" : 47.54169049999999,
                  "lng" : 1.2266847
               }
            },
            "location" : {
               "lat" : 47.6084538,
               "lng" : 1.3176281
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 47.6910195,
                  "lng" : 1.4106235
               },
               "southwest" : {
                  "lat" : 47.54169049999999,
                  "lng" : 1.2266847
               }
            }
         },
         "place_id" : "ChIJR1t1cA1Y40cRsAsKiNrIDRw",
         "postcode_localities" : [
            "Blois",
            "Saint-Denis-sur-Loire",
            "Saint-Sulpice-de-Pommeray",
            "Villebarou",
            "Villerbon"
         ],
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )