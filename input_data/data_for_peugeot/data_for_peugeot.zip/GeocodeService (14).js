/**/_xdc_._jhah1a && _xdc_._jhah1a( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "15000",
               "short_name" : "15000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Naucelles",
               "short_name" : "Naucelles",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Cantal",
               "short_name" : "Cantal",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Auvergne-Rhône-Alpes",
               "short_name" : "Auvergne-Rhône-Alpes",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "15000 Naucelles, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 44.9662634,
                  "lng" : 2.4924644
               },
               "southwest" : {
                  "lat" : 44.8899538,
                  "lng" : 2.3904621
               }
            },
            "location" : {
               "lat" : 44.92756019999999,
               "lng" : 2.4307539
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 44.9662634,
                  "lng" : 2.4924644
               },
               "southwest" : {
                  "lat" : 44.8899538,
                  "lng" : 2.3904621
               }
            }
         },
         "place_id" : "ChIJMxhY96JVrRIR4D8OKbM8CRw",
         "postcode_localities" : [ "Aurillac", "Naucelles" ],
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )