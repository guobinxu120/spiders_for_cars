/**/_xdc_._lzhh4i && _xdc_._lzhh4i( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "77000",
               "short_name" : "77000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Livry-sur-Seine",
               "short_name" : "Livry-sur-Seine",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Seine-et-Marne",
               "short_name" : "Seine-et-Marne",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Île-de-France",
               "short_name" : "Île-de-France",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "77000 Livry-sur-Seine, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 48.5606966,
                  "lng" : 2.7340105
               },
               "southwest" : {
                  "lat" : 48.48709480000001,
                  "lng" : 2.6287111
               }
            },
            "location" : {
               "lat" : 48.5175192,
               "lng" : 2.684649
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 48.5606966,
                  "lng" : 2.7340105
               },
               "southwest" : {
                  "lat" : 48.48709480000001,
                  "lng" : 2.6287111
               }
            }
         },
         "place_id" : "ChIJtbda66bw5UcRoFrY4caCCxw",
         "postcode_localities" : [ "La Rochette", "Livry-sur-Seine", "Melun", "Vaux-le-Pénil" ],
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )