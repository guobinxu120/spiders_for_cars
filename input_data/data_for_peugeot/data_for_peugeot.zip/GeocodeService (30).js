/**/_xdc_._ez368k && _xdc_._ez368k( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "31000",
               "short_name" : "31000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Toulouse",
               "short_name" : "Toulouse",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Haute-Garonne",
               "short_name" : "Haute-Garonne",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Occitanie",
               "short_name" : "Occitanie",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "31000 Toulouse, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 43.6161263,
                  "lng" : 1.456655
               },
               "southwest" : {
                  "lat" : 43.5920152,
                  "lng" : 1.4126725
               }
            },
            "location" : {
               "lat" : 43.6046256,
               "lng" : 1.444205
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 43.6161263,
                  "lng" : 1.456655
               },
               "southwest" : {
                  "lat" : 43.5920152,
                  "lng" : 1.4126725
               }
            }
         },
         "place_id" : "ChIJfW_a5WW7rhIR8HbZeJ_2Bhw",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )