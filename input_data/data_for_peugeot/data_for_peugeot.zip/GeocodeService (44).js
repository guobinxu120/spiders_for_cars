/**/_xdc_._onu76q && _xdc_._onu76q( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "45000",
               "short_name" : "45000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Orléans",
               "short_name" : "Orléans",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Loiret",
               "short_name" : "Loiret",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Centre-Val de Loire",
               "short_name" : "Centre-Val de Loire",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "45000 Orléans, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 47.9335327,
                  "lng" : 1.944105
               },
               "southwest" : {
                  "lat" : 47.8944151,
                  "lng" : 1.8758486
               }
            },
            "location" : {
               "lat" : 47.9108329,
               "lng" : 1.9157977
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 47.9335327,
                  "lng" : 1.944105
               },
               "southwest" : {
                  "lat" : 47.8944151,
                  "lng" : 1.8758486
               }
            }
         },
         "place_id" : "ChIJFdvBzy_75EcR4EBIRdrIDRw",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )