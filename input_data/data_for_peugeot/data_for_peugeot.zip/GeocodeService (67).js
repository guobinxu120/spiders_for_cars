/**/_xdc_._s61cmp && _xdc_._s61cmp( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "68000",
               "short_name" : "68000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Colmar",
               "short_name" : "Colmar",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Haut-Rhin",
               "short_name" : "Haut-Rhin",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Grand Est",
               "short_name" : "Grand Est",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "68000 Colmar, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 48.1821077,
                  "lng" : 7.4690198
               },
               "southwest" : {
                  "lat" : 48.0407295,
                  "lng" : 7.315542499999999
               }
            },
            "location" : {
               "lat" : 48.0927988,
               "lng" : 7.370460299999999
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 48.1821077,
                  "lng" : 7.4690198
               },
               "southwest" : {
                  "lat" : 48.0407295,
                  "lng" : 7.315542499999999
               }
            }
         },
         "place_id" : "ChIJ9Vc8S4NokUcRUORxAL1fChw",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )