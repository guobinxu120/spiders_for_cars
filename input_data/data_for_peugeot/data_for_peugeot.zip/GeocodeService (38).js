/**/_xdc_._j21edf && _xdc_._j21edf( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "39000",
               "short_name" : "39000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Jura",
               "short_name" : "Jura",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Bourgogne-Franche-Comté",
               "short_name" : "Bourgogne-Franche-Comté",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "39000, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 46.6951916,
                  "lng" : 5.5822213
               },
               "southwest" : {
                  "lat" : 46.6564184,
                  "lng" : 5.5323864
               }
            },
            "location" : {
               "lat" : 46.6758932,
               "lng" : 5.560297500000001
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 46.6951916,
                  "lng" : 5.5822213
               },
               "southwest" : {
                  "lat" : 46.6564184,
                  "lng" : 5.5323864
               }
            }
         },
         "place_id" : "ChIJBZN1K_LXjEcRIJ5HGTjOCRw",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )