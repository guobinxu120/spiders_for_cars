/**/_xdc_._k5mwe0 && _xdc_._k5mwe0( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "61000",
               "short_name" : "61000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Saint-Germain-du-Corbéis",
               "short_name" : "Saint-Germain-du-Corbéis",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Orne",
               "short_name" : "Orne",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Normandy",
               "short_name" : "Normandy",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "61000 Saint-Germain-du-Corbéis, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 48.455592,
                  "lng" : 0.158229
               },
               "southwest" : {
                  "lat" : 48.4061946,
                  "lng" : 0.02944059999999999
               }
            },
            "location" : {
               "lat" : 48.4337291,
               "lng" : 0.0894789
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 48.455592,
                  "lng" : 0.158229
               },
               "southwest" : {
                  "lat" : 48.4061946,
                  "lng" : 0.02944059999999999
               }
            }
         },
         "place_id" : "ChIJaxk2cYUM4kcREGnKj0sUDBw",
         "postcode_localities" : [ "Alençon", "Cerisé", "Saint-Germain-du-Corbéis" ],
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )