/**/_xdc_._dz30vt && _xdc_._dz30vt( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "70000",
               "short_name" : "70000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Cerre-lès-Noroy",
               "short_name" : "Cerre-lès-Noroy",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Haute-Saône",
               "short_name" : "Haute-Saône",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Bourgogne-Franche-Comté",
               "short_name" : "Bourgogne-Franche-Comté",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "70000 Cerre-lès-Noroy, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 47.7222211,
                  "lng" : 6.3397008
               },
               "southwest" : {
                  "lat" : 47.4978769,
                  "lng" : 5.9795584
               }
            },
            "location" : {
               "lat" : 47.6371986,
               "lng" : 6.176517
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 47.7222211,
                  "lng" : 6.3397008
               },
               "southwest" : {
                  "lat" : 47.4978769,
                  "lng" : 5.9795584
               }
            }
         },
         "place_id" : "ChIJ4W5Rz9rykkcRYPNHGTjOCRw",
         "postcode_localities" : [
            "Andelarre",
            "Andelarrot",
            "Auxon",
            "Baignes",
            "Boursières",
            "Cerre-lès-Noroy",
            "Chariez",
            "Charmoille",
            "Clans",
            "Colombe-lès-Vesoul",
            "Colombier",
            "Comberjon",
            "Coulevon",
            "Dampvalley-lès-Colombe",
            "Flagy",
            "Frotey-lès-Vesoul",
            "La Demie",
            "Le Magnoray",
            "Mailley-et-Chazelot",
            "Mont-le-Vernois",
            "Montcey",
            "Montigny-lès-Vesoul",
            "Navenne",
            "Neurey-lès-la-Demie",
            "Noidans-lès-Vesoul",
            "Noroy-le-Bourg",
            "Pusey",
            "Pusy-et-Épenoux",
            "Quincey",
            "Raze",
            "Rosey",
            "Vaivre-et-Montoille",
            "Vallerois-Lorioz",
            "Vallerois-le-Bois",
            "Velle-le-Châtel",
            "Vellefaux",
            "Velleguindry-et-Levrecey",
            "Vesoul",
            "Villeparois",
            "Villers-le-Sec",
            "Échenoz-la-Méline",
            "Échenoz-le-Sec"
         ],
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )