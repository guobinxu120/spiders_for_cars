/**/_xdc_._l5n1qr && _xdc_._l5n1qr( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "22000",
               "short_name" : "22000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Saint-Brieuc",
               "short_name" : "Saint-Brieuc",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Côtes-d'Armor",
               "short_name" : "Côtes-d'Armor",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Brittany",
               "short_name" : "Brittany",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "22000 Saint-Brieuc, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 48.53421729999999,
                  "lng" : -2.7095645
               },
               "southwest" : {
                  "lat" : 48.4863657,
                  "lng" : -2.8214358
               }
            },
            "location" : {
               "lat" : 48.5105447,
               "lng" : -2.7680099
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 48.53421729999999,
                  "lng" : -2.7095645
               },
               "southwest" : {
                  "lat" : 48.4863657,
                  "lng" : -2.8214358
               }
            }
         },
         "place_id" : "ChIJAytWKUEdDkgR4PXzdtClDBw",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )