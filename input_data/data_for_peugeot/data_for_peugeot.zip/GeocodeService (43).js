/**/_xdc_._slafak && _xdc_._slafak( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "44000",
               "short_name" : "44000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Nantes",
               "short_name" : "Nantes",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Loire-Atlantique",
               "short_name" : "Loire-Atlantique",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Pays de la Loire",
               "short_name" : "Pays de la Loire",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "44000 Nantes, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 47.2355199,
                  "lng" : -1.5156055
               },
               "southwest" : {
                  "lat" : 47.2083442,
                  "lng" : -1.5852857
               }
            },
            "location" : {
               "lat" : 47.2239586,
               "lng" : -1.5408058
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 47.2355199,
                  "lng" : -1.5156055
               },
               "southwest" : {
                  "lat" : 47.2083442,
                  "lng" : -1.5852857
               }
            }
         },
         "place_id" : "ChIJXypxyaLuBUgRoH_hoFU3DRw",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )