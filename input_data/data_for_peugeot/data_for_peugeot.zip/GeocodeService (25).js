/**/_xdc_._5fu5bf && _xdc_._5fu5bf( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "26000",
               "short_name" : "26000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Valence",
               "short_name" : "Valence",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Drôme",
               "short_name" : "Drôme",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Auvergne-Rhône-Alpes",
               "short_name" : "Auvergne-Rhône-Alpes",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "26000 Valence, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 44.9597553,
                  "lng" : 4.978322900000001
               },
               "southwest" : {
                  "lat" : 44.8870661,
                  "lng" : 4.8536392
               }
            },
            "location" : {
               "lat" : 44.92272,
               "lng" : 4.9087118
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 44.9597553,
                  "lng" : 4.978322900000001
               },
               "southwest" : {
                  "lat" : 44.8870661,
                  "lng" : 4.8536392
               }
            }
         },
         "place_id" : "ChIJxyEyxplX9UcR8ELkQS6rCBw",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )