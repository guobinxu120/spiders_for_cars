/**/_xdc_._i2190o && _xdc_._i2190o( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "78000",
               "short_name" : "78000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Versailles",
               "short_name" : "Versailles",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Yvelines",
               "short_name" : "Yvelines",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Île-de-France",
               "short_name" : "Île-de-France",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "78000 Versailles, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 48.8285917,
                  "lng" : 2.1684093
               },
               "southwest" : {
                  "lat" : 48.7791767,
                  "lng" : 2.0700001
               }
            },
            "location" : {
               "lat" : 48.8051741,
               "lng" : 2.1219587
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 48.8285917,
                  "lng" : 2.1684093
               },
               "southwest" : {
                  "lat" : 48.7791767,
                  "lng" : 2.0700001
               }
            }
         },
         "place_id" : "ChIJ4VqV9L595kcRMHLY4caCCxw",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )