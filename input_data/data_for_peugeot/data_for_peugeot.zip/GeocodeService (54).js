/**/_xdc_._eju3kp && _xdc_._eju3kp( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "55000",
               "short_name" : "55000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Tannois",
               "short_name" : "Tannois",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Meuse",
               "short_name" : "Meuse",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Grand Est",
               "short_name" : "Grand Est",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "55000 Tannois, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 48.9137612,
                  "lng" : 5.3619989
               },
               "southwest" : {
                  "lat" : 48.6634502,
                  "lng" : 4.9804963
               }
            },
            "location" : {
               "lat" : 48.8039712,
               "lng" : 5.1830539
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 48.9137612,
                  "lng" : 5.3619989
               },
               "southwest" : {
                  "lat" : 48.6634502,
                  "lng" : 4.9804963
               }
            }
         },
         "place_id" : "ChIJq-HeMvJw60cRkMBxAL1fChw",
         "postcode_localities" : [
            "Bar-le-Duc",
            "Behonne",
            "Beurey-sur-Saulx",
            "Brillon-en-Barrois",
            "Chardogne",
            "Combles-en-Barrois",
            "Fains-Véel",
            "Guerpont",
            "Géry",
            "Haironville",
            "Les Hauts-de-Chée",
            "Lisle-en-Rigault",
            "Loisey",
            "Longeville-en-Barrois",
            "Montplonne",
            "Naives-Rosières",
            "Resson",
            "Robert-Espagne",
            "Rumont",
            "Salmagne",
            "Saudrupt",
            "Savonnières-devant-Bar",
            "Seigneulles",
            "Silmont",
            "Tannois",
            "Trémont-sur-Saulx",
            "Val-d'Ornain",
            "Vavincourt",
            "Ville-sur-Saulx",
            "Érize-Saint-Dizier"
         ],
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )