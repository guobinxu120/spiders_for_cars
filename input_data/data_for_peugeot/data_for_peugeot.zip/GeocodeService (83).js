/**/_xdc_._nnu1tz && _xdc_._nnu1tz( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "84000",
               "short_name" : "84000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "84000, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 43.9949375,
                  "lng" : 4.8834563
               },
               "southwest" : {
                  "lat" : 43.9112283,
                  "lng" : 4.7399281
               }
            },
            "location" : {
               "lat" : 43.94700419999999,
               "lng" : 4.8209596
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 43.9949375,
                  "lng" : 4.8834563
               },
               "southwest" : {
                  "lat" : 43.9112283,
                  "lng" : 4.7399281
               }
            }
         },
         "place_id" : "ChIJK4RPQX_stRIRgPm2UKkZCBw",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )