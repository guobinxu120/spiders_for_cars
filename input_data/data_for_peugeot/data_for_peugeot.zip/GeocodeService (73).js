/**/_xdc_._xru5g0 && _xdc_._xru5g0( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "74000",
               "short_name" : "74000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Annecy",
               "short_name" : "Annecy",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Haute-Savoie",
               "short_name" : "Haute-Savoie",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Auvergne-Rhône-Alpes",
               "short_name" : "Auvergne-Rhône-Alpes",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "74000 Annecy, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 45.9303574,
                  "lng" : 6.1523827
               },
               "southwest" : {
                  "lat" : 45.84956100000001,
                  "lng" : 6.100838599999999
               }
            },
            "location" : {
               "lat" : 45.8971718,
               "lng" : 6.1251614
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 45.9303574,
                  "lng" : 6.1523827
               },
               "southwest" : {
                  "lat" : 45.84956100000001,
                  "lng" : 6.100838599999999
               }
            }
         },
         "place_id" : "ChIJISkk_gKQi0cRMIfkQS6rCBw",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )