/**/_xdc_._lqe4fn && _xdc_._lqe4fn( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "07000",
               "short_name" : "07000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Freyssenet",
               "short_name" : "Freyssenet",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Ardèche",
               "short_name" : "Ardèche",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Auvergne-Rhône-Alpes",
               "short_name" : "Auvergne-Rhône-Alpes",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "07000 Freyssenet, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 44.8136167,
                  "lng" : 4.7282272
               },
               "southwest" : {
                  "lat" : 44.6693507,
                  "lng" : 4.428755
               }
            },
            "location" : {
               "lat" : 44.7400888,
               "lng" : 4.583078899999999
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 44.8136167,
                  "lng" : 4.7282272
               },
               "southwest" : {
                  "lat" : 44.6693507,
                  "lng" : 4.428755
               }
            }
         },
         "place_id" : "ChIJVV3oN786tRIREDsOKbM8CRw",
         "postcode_localities" : [
            "Ajoux",
            "Coux",
            "Creysseilles",
            "Flaviac",
            "Freyssenet",
            "Gourdon",
            "Lyas",
            "Pourchères",
            "Pranles",
            "Privas",
            "Saint-Julien-en-Saint-Alban",
            "Saint-Priest",
            "Veyras"
         ],
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )