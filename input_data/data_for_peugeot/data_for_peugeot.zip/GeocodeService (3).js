/**/_xdc_._xiqsr5 && _xdc_._xiqsr5( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "04000",
               "short_name" : "04000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Digne",
               "short_name" : "Digne",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Alpes-de-Haute-Provence",
               "short_name" : "Alpes-de-Haute-Provence",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Provence-Alpes-Côte d'Azur",
               "short_name" : "Provence-Alpes-Côte d'Azur",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "04000 Digne, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 44.2401744,
                  "lng" : 6.3409494
               },
               "southwest" : {
                  "lat" : 44.0026438,
                  "lng" : 6.157714899999999
               }
            },
            "location" : {
               "lat" : 44.1080239,
               "lng" : 6.2057449
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 44.2401744,
                  "lng" : 6.3409494
               },
               "southwest" : {
                  "lat" : 44.0026438,
                  "lng" : 6.157714899999999
               }
            }
         },
         "place_id" : "ChIJPZASadqEyxIRULO2UKkZCBw",
         "postcode_localities" : [ "Digne", "Entrages", "La Robine-sur-Galabre" ],
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )