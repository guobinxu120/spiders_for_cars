/**/_xdc_._v9n5cs && _xdc_._v9n5cs( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "12000",
               "short_name" : "12000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Le Monastère",
               "short_name" : "Le Monastère",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Aveyron",
               "short_name" : "Aveyron",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Occitanie",
               "short_name" : "Occitanie",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "12000 Le Monastère, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 44.3821583,
                  "lng" : 2.6111417
               },
               "southwest" : {
                  "lat" : 44.3128079,
                  "lng" : 2.5242648
               }
            },
            "location" : {
               "lat" : 44.3467485,
               "lng" : 2.5742907
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 44.3821583,
                  "lng" : 2.6111417
               },
               "southwest" : {
                  "lat" : 44.3128079,
                  "lng" : 2.5242648
               }
            }
         },
         "place_id" : "ChIJu7f2W6R9shIRcErZeJ_2Bhw",
         "postcode_localities" : [ "Le Monastère", "Onet-le-Château", "Rodez" ],
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )