/**/_xdc_._wiqnee && _xdc_._wiqnee( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "43000",
               "short_name" : "43000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Le Puy",
               "short_name" : "Le Puy",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Haute-Loire",
               "short_name" : "Haute-Loire",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Auvergne-Rhône-Alpes",
               "short_name" : "Auvergne-Rhône-Alpes",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "43000 Le Puy, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 45.1072752,
                  "lng" : 3.9337139
               },
               "southwest" : {
                  "lat" : 44.9990741,
                  "lng" : 3.8059062
               }
            },
            "location" : {
               "lat" : 45.0655906,
               "lng" : 3.8627087
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 45.1072752,
                  "lng" : 3.9337139
               },
               "southwest" : {
                  "lat" : 44.9990741,
                  "lng" : 3.8059062
               }
            }
         },
         "place_id" : "ChIJ1z27DQ_79UcRAGIOKbM8CRw",
         "postcode_localities" : [ "Aiguilhe", "Ceyssac", "Espaly-Saint-Marcel", "Le Puy", "Polignac" ],
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )