/**/_xdc_._hha6bs && _xdc_._hha6bs( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "93000",
               "short_name" : "93000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Bobigny",
               "short_name" : "Bobigny",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Seine-Saint-Denis",
               "short_name" : "Seine-Saint-Denis",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Île-de-France",
               "short_name" : "Île-de-France",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "93000 Bobigny, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 48.9193556,
                  "lng" : 2.4762014
               },
               "southwest" : {
                  "lat" : 48.8951585,
                  "lng" : 2.4101326
               }
            },
            "location" : {
               "lat" : 48.9100302,
               "lng" : 2.422169
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 48.9193556,
                  "lng" : 2.4762014
               },
               "southwest" : {
                  "lat" : 48.8951585,
                  "lng" : 2.4101326
               }
            }
         },
         "place_id" : "ChIJw91yn8Ns5kcR4IHY4caCCxw",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )