/**/_xdc_._w3hkqj && _xdc_._w3hkqj( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "67000",
               "short_name" : "67000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Strasbourg",
               "short_name" : "Strasbourg",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Bas-Rhin",
               "short_name" : "Bas-Rhin",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Grand Est",
               "short_name" : "Grand Est",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "67000 Strasbourg, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 48.6461915,
                  "lng" : 7.836255899999999
               },
               "southwest" : {
                  "lat" : 48.5507514,
                  "lng" : 7.723974399999999
               }
            },
            "location" : {
               "lat" : 48.6019858,
               "lng" : 7.7835217
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 48.6461915,
                  "lng" : 7.836255899999999
               },
               "southwest" : {
                  "lat" : 48.5507514,
                  "lng" : 7.723974399999999
               }
            }
         },
         "place_id" : "ChIJs-1yGJPIlkcR8NtxAL1fChw",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )