/**/_xdc_._26qckb && _xdc_._26qckb( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "73000",
               "short_name" : "73000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Sonnaz",
               "short_name" : "Sonnaz",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Savoie",
               "short_name" : "Savoie",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Auvergne-Rhône-Alpes",
               "short_name" : "Auvergne-Rhône-Alpes",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "73000 Sonnaz, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 45.6426007,
                  "lng" : 5.9520143
               },
               "southwest" : {
                  "lat" : 45.496538,
                  "lng" : 5.8712795
               }
            },
            "location" : {
               "lat" : 45.5700276,
               "lng" : 5.929571300000001
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 45.6426007,
                  "lng" : 5.9520143
               },
               "southwest" : {
                  "lat" : 45.496538,
                  "lng" : 5.8712795
               }
            }
         },
         "place_id" : "ChIJBwJC6lCoi0cRkIPkQS6rCBw",
         "postcode_localities" : [
            "Barberaz",
            "Bassens",
            "Chambéry",
            "Jacob-Bellecombette",
            "Montagnole",
            "Sonnaz"
         ],
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )