/**/_xdc_._djty7y && _xdc_._djty7y( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "94000",
               "short_name" : "94000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Créteil",
               "short_name" : "Créteil",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Val-de-Marne",
               "short_name" : "Val-de-Marne",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Île-de-France",
               "short_name" : "Île-de-France",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "94000 Créteil, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 48.8073389,
                  "lng" : 2.4773736
               },
               "southwest" : {
                  "lat" : 48.7619287,
                  "lng" : 2.4274896
               }
            },
            "location" : {
               "lat" : 48.78848230000001,
               "lng" : 2.4567614
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 48.8073389,
                  "lng" : 2.4773736
               },
               "southwest" : {
                  "lat" : 48.7619287,
                  "lng" : 2.4274896
               }
            }
         },
         "place_id" : "ChIJl3xXlLIM5kcR8ITY4caCCxw",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )