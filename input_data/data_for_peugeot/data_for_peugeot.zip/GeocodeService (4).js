/**/_xdc_._tlaknb && _xdc_._tlaknb( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "05000",
               "short_name" : "05000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Pelleautier",
               "short_name" : "Pelleautier",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Hautes-Alpes",
               "short_name" : "Hautes-Alpes",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Provence-Alpes-Côte d'Azur",
               "short_name" : "Provence-Alpes-Côte d'Azur",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "05000 Pelleautier, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 44.6648404,
                  "lng" : 6.1735333
               },
               "southwest" : {
                  "lat" : 44.4640492,
                  "lng" : 5.9606838
               }
            },
            "location" : {
               "lat" : 44.5749377,
               "lng" : 6.1102943
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 44.6648404,
                  "lng" : 6.1735333
               },
               "southwest" : {
                  "lat" : 44.4640492,
                  "lng" : 5.9606838
               }
            }
         },
         "place_id" : "ChIJW0H3wok_yxIRELe2UKkZCBw",
         "postcode_localities" : [
            "Châteauvieux",
            "Gap",
            "La Bâtie-Vieille",
            "La Freissinouse",
            "La Rochette",
            "Neffes",
            "Pelleautier",
            "Rambaud"
         ],
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )