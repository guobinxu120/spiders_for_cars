/**/_xdc_._3v2x9s && _xdc_._3v2x9s( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "80000",
               "short_name" : "80000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Amiens",
               "short_name" : "Amiens",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Somme",
               "short_name" : "Somme",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Hauts-de-France",
               "short_name" : "Hauts-de-France",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "80000 Amiens, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 49.9187331,
                  "lng" : 2.3359537
               },
               "southwest" : {
                  "lat" : 49.8738889,
                  "lng" : 2.2234834
               }
            },
            "location" : {
               "lat" : 49.89905,
               "lng" : 2.2752772
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 49.9187331,
                  "lng" : 2.3359537
               },
               "southwest" : {
                  "lat" : 49.8738889,
                  "lng" : 2.2234834
               }
            }
         },
         "place_id" : "ChIJSUzCdQ2E50cR8EAl8UHxChw",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )