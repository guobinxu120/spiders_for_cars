/**/_xdc_._qwxul3 && _xdc_._qwxul3( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "37000",
               "short_name" : "37000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Tours",
               "short_name" : "Tours",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Indre-et-Loire",
               "short_name" : "Indre-et-Loire",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Centre-Val de Loire",
               "short_name" : "Centre-Val de Loire",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "37000 Tours, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 47.4039264,
                  "lng" : 0.7373837999999999
               },
               "southwest" : {
                  "lat" : 47.3717047,
                  "lng" : 0.6616356999999999
               }
            },
            "location" : {
               "lat" : 47.3832745,
               "lng" : 0.6897966
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 47.4039264,
                  "lng" : 0.7373837999999999
               },
               "southwest" : {
                  "lat" : 47.3717047,
                  "lng" : 0.6616356999999999
               }
            }
         },
         "place_id" : "ChIJ_4ZM9zXU_EcR4AMKiNrIDRw",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )