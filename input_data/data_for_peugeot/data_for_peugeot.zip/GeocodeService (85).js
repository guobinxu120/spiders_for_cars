/**/_xdc_._fsxlmb && _xdc_._fsxlmb( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "86000",
               "short_name" : "86000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Poitiers",
               "short_name" : "Poitiers",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Vienne",
               "short_name" : "Vienne",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Nouvelle-Aquitaine",
               "short_name" : "Nouvelle-Aquitaine",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "86000 Poitiers, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 46.6271988,
                  "lng" : 0.4519995
               },
               "southwest" : {
                  "lat" : 46.5422398,
                  "lng" : 0.2911416000000001
               }
            },
            "location" : {
               "lat" : 46.5831743,
               "lng" : 0.3464227
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 46.6271988,
                  "lng" : 0.4519995
               },
               "southwest" : {
                  "lat" : 46.5422398,
                  "lng" : 0.2911416000000001
               }
            }
         },
         "place_id" : "ChIJr70kiZm-_UcRUMKFqpXTBRw",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )