/**/_xdc_._ihaboj && _xdc_._ihaboj( {
   "results" : [
      {
         "address_components" : [
            {
               "long_name" : "54000",
               "short_name" : "54000",
               "types" : [ "postal_code" ]
            },
            {
               "long_name" : "Nancy",
               "short_name" : "Nancy",
               "types" : [ "locality", "political" ]
            },
            {
               "long_name" : "Meurthe-et-Moselle",
               "short_name" : "Meurthe-et-Moselle",
               "types" : [ "administrative_area_level_2", "political" ]
            },
            {
               "long_name" : "Grand Est",
               "short_name" : "Grand Est",
               "types" : [ "administrative_area_level_1", "political" ]
            },
            {
               "long_name" : "France",
               "short_name" : "FR",
               "types" : [ "country", "political" ]
            }
         ],
         "formatted_address" : "54000 Nancy, France",
         "geometry" : {
            "bounds" : {
               "northeast" : {
                  "lat" : 48.70924189999999,
                  "lng" : 6.2126679
               },
               "southwest" : {
                  "lat" : 48.6668706,
                  "lng" : 6.1342325
               }
            },
            "location" : {
               "lat" : 48.6896459,
               "lng" : 6.1737197
            },
            "location_type" : "APPROXIMATE",
            "viewport" : {
               "northeast" : {
                  "lat" : 48.70924189999999,
                  "lng" : 6.2126679
               },
               "southwest" : {
                  "lat" : 48.6668706,
                  "lng" : 6.1342325
               }
            }
         },
         "place_id" : "ChIJk_RcM3GYlEcR4LNxAL1fChw",
         "types" : [ "postal_code" ]
      }
   ],
   "status" : "OK"
}
 )